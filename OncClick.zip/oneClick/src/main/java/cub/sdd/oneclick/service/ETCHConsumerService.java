package cub.sdd.oneclick.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ETCHConsumerService {

    @Autowired
    private Count count;

    @KafkaListener(topics = "${cub.spring.kafka.etch.topic}", groupId = "${cub.spring.kafka.etch.consumer.group-id}", containerFactory = "ETCHContainerFactory")
    public void listen(String message) {
        log.info("ETCH收到訊息!>>>>>>> " + message);
        count.plusETCH();
    }
}
