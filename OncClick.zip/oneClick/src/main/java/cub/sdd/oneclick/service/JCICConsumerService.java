package cub.sdd.oneclick.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class JCICConsumerService {

    @Autowired
    private Count count;

    @KafkaListener(topics = "${cub.spring.kafka.jcic.topic}", groupId = "${cub.spring.kafka.jcic.consumer.group-id}", containerFactory = "JCICContainerFactory")
    public void listen(String message) {
        log.info("JCIC收到訊息!>>>>>>> " + message);
        count.plusJCIC();
    }
}
