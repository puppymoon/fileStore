package cub.sdd.oneclick.service;

import java.util.List;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AsyncProducerService {

    @Value("${cub.spring.kafka.jcic.topic}")
    private String topicJCIC;

    @Value("${cub.spring.kafka.etch.topic}")
    private String topicETCH;

    @Value("${cub.spring.kafka.intr.topic}")
    private String topicINTR;

    @Autowired
    @Qualifier("JCICKafkaTemplate")
    private KafkaTemplate<String, String> JCICKafkaTemplate;

    @Autowired
    @Qualifier("ETCHKafkaTemplate")
    private KafkaTemplate<String, String> ETCHKafkaTemplate;

    @Autowired
    @Qualifier("INTRKafkaTemplate")
    private KafkaTemplate<String, String> INTRKafkaTemplate;

    @Async("asyncTaskExecutor")
    public void produceJCIC(List<String> listJCIC) {

        for (String str : listJCIC) {

            JCICKafkaTemplate.executeInTransaction(kafkaTemplate -> {

                ProducerRecord<String, String> producerRecordJCIC = new ProducerRecord<>(topicJCIC, str);
                ListenableFuture<SendResult<String, String>> listenableFutureJCIC = kafkaTemplate.send(producerRecordJCIC);
                listenableFutureJCIC.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

                    @Override
                    public void onSuccess(SendResult<String, String> result) {
                        //                    log.info("message sent, partition={}, offset={}", result.getRecordMetadata().partition(),
                        //                        result.getRecordMetadata().offset());
                    }

                    @Override
                    public void onFailure(Throwable throwable) {
                        log.error("failed to send, message={}", str, throwable);
                    }
                });

                return null;
            });
        }

    }

    @Async("asyncTaskExecutor")
    public void produceETCH(List<String> listETCH) {

        for (String str : listETCH) {

            ETCHKafkaTemplate.executeInTransaction(kafkaTemplate -> {

                ProducerRecord<String, String> producerRecordETCH = new ProducerRecord<>(topicETCH, str);
                ListenableFuture<SendResult<String, String>> listenableFutureETCH = kafkaTemplate.send(producerRecordETCH);
                listenableFutureETCH.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

                    @Override
                    public void onSuccess(SendResult<String, String> result) {
                        //                    log.info("message sent, partition={}, offset={}", result.getRecordMetadata().partition(),
                        //                        result.getRecordMetadata().offset());
                    }

                    @Override
                    public void onFailure(Throwable throwable) {
                        log.error("failed to send, message={}", str, throwable);
                    }
                });

                return null;
            });
        }

    }

    @Async("asyncTaskExecutor")
    public void produceINTR(List<String> listINTR) {

        for (String str : listINTR) {
            INTRKafkaTemplate.executeInTransaction(kafkaTemplate -> {

                ProducerRecord<String, String> producerRecordINTR = new ProducerRecord<>(topicINTR, str);
                ListenableFuture<SendResult<String, String>> listenableFutureINTR = kafkaTemplate.send(producerRecordINTR);
                listenableFutureINTR.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

                    @Override
                    public void onSuccess(SendResult<String, String> result) {
                        //                    log.info("message sent, partition={}, offset={}", result.getRecordMetadata().partition(),
                        //                        result.getRecordMetadata().offset());
                    }

                    @Override
                    public void onFailure(Throwable throwable) {
                        log.error("failed to send, message={}", str, throwable);
                    }
                });

                return null;
            });
        }

    }

}
