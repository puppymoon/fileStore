package cub.sdd.oneclick.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cub.sdd.oneclick.service.Count;
import cub.sdd.oneclick.service.KafkaProducerService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api")
public class TestController {

    @Autowired
    private KafkaProducerService kafkaProducerService;

    @Autowired
    private Count count;

    @PostMapping(path = "/send")
    public void send(int caseJCIC, int caseETCH, int caseINTR) {

        log.info("/api/send 收到訊息.");

        List<String> listJCIC = new ArrayList<>();
        List<String> listETCH = new ArrayList<>();
        List<String> listINTR = new ArrayList<>();

        for (int i = 1; i <= caseJCIC; i++) {
            listJCIC.add("JCIC" + i);
        }
        for (int i = 1; i <= caseETCH; i++) {
            listETCH.add("ETCH" + i);
        }
        for (int i = 1; i <= caseINTR; i++) {
            listINTR.add("INTR" + i);
        }

        log.info("開始發送給producer.");
        kafkaProducerService.produce(listJCIC, listETCH, listINTR);
        log.info("結束發送給producer.");

    }

    @PostMapping(path = "/getCount")
    public String getCount() {
        StringBuilder sb = new StringBuilder();
        sb.append("JCIC 次數為: ");
        sb.append(count.getCountJCIC());
        sb.append(System.getProperty("line.separator"));
        sb.append("ETCH 次數為: ");
        sb.append(count.getCountETCH());
        sb.append(System.getProperty("line.separator"));
        sb.append("INTR 次數為: ");
        sb.append(count.getCountINTR());
        return sb.toString();
    }

    @PostMapping(path = "/resetCount")
    public void resetCount() {
        count.resetCount();
    }

}
