package cub.sdd.oneclick.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
public class KafkaProducerService {

    @Autowired
    private AsyncProducerService asyncProducerService;

    public void produce(List<String> listJCIC, List<String> listETCH, List<String> listINTR) {

        asyncProducerService.produceJCIC(listJCIC);
        asyncProducerService.produceETCH(listETCH);
        asyncProducerService.produceINTR(listINTR);

    }

}
