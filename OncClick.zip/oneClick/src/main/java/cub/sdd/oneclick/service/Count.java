package cub.sdd.oneclick.service;

import org.springframework.stereotype.Component;

@Component
public class Count {

    private int countJCIC = 0;

    private int countETCH = 0;

    private int countINTR = 0;

    public int getCountJCIC() {
        return countJCIC;
    }

    public int getCountETCH() {
        return countETCH;
    }

    public int getCountINTR() {
        return countINTR;
    }

    public void plusJCIC() {
        this.countJCIC += 1;
    }

    public void plusETCH() {
        this.countETCH += 1;
    }

    public void plusINTR() {
        this.countINTR += 1;
    }

    public void resetCount() {
        this.countJCIC = 0;
        this.countETCH = 0;
        this.countINTR = 0;
    }

}
