package cub.sdd.oneclick.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class INTRConsumerService {

    @Autowired
    private Count count;

    @KafkaListener(topics = "${cub.spring.kafka.intr.topic}", groupId = "${cub.spring.kafka.intr.consumer.group-id}", containerFactory = "INTRContainerFactory")
    public void listen(String message) {
        log.info("INTR收到訊息!>>>>>>> " + message);
        count.plusINTR();
    }
}
