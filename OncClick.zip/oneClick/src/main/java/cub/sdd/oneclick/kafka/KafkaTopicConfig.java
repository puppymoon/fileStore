package cub.sdd.oneclick.kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;

@Configuration
public class KafkaTopicConfig {

    @Value("${cub.spring.kafka.bootstrap-servers}")
    private String servers;

    @Value("${cub.spring.kafka.jcic.topic}")
    private String topicJCIC;

    @Value("${cub.spring.kafka.etch.topic}")
    private String topicETCH;

    @Value("${cub.spring.kafka.intr.topic}")
    private String topicINTR;

    @Bean
    public KafkaAdmin admin() {
        Map<String, Object> configs = new HashMap<>();
        configs.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, servers);
        return new KafkaAdmin(configs);
    }

    /**
     * JCIC Topic建置
     * @return
     */
    @Bean("topic_jcic")
    public NewTopic topic1() {
        // 5 partition 1 replica
        return TopicBuilder.name(topicJCIC).partitions(3).replicas(1).build();
    }

    /**
     * ETCH Topic建置
     * @return
     */
    @Bean("topic_etch")
    public NewTopic topic2() {
        // 5 partition 1 replica
        return TopicBuilder.name(topicETCH).partitions(3).replicas(1).build();
    }

    /**
     * INTR Topic建置
     * @return
     */
    @Bean("topic_intr")
    public NewTopic topic3() {
        // 5 partition 1 replica
        return TopicBuilder.name(topicINTR).partitions(3).replicas(1).build();
        //        return TopicBuilder.name(topicINTR).partitions(5).replicas(1).compact().build();
    }

}